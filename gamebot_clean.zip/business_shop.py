import time
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils import get_user, get_balance, update_balance, save_user_data, format_amount

router = Router()

SELL_RATIO = 0.6

BUSINESSES = [
    {
        "name": "🥤 Ларёк",
        "desc": "Небольшой торговый ларёк в оживлённом месте. Минимальные вложения, стабильный поток покупателей — идеальный старт для начинающего предпринимателя.",
        "price": 350_000,
        "income_per_hour": 4_500,
    },
    {
        "name": "☕ Кофейня",
        "desc": "Стильная кофейня в деловом квартале города. Авторские напитки, уютная атмосфера и очередь из постоянных гостей каждое утро.",
        "price": 900_000,
        "income_per_hour": 9_500,
    },
    {
        "name": "🍔 Бургерная",
        "desc": "Популярная бургерная с фирменным меню и живой музыкой по вечерам. Молодёжная аудитория и высокий средний чек обеспечивают уверенный доход.",
        "price": 1_800_000,
        "income_per_hour": 18_000,
    },
    {
        "name": "⛽ АЗС",
        "desc": "Современная автозаправочная станция на оживлённой трассе. Круглосуточный трафик, магазин при станции и автомойка — три источника прибыли в одном.",
        "price": 4_000_000,
        "income_per_hour": 35_000,
    },
    {
        "name": "🚕 Таксопарк",
        "desc": "Собственный таксопарк с флотом современных автомобилей. Подключение к ведущим агрегаторам и диспетчерская служба работают за вас 24/7.",
        "price": 8_000_000,
        "income_per_hour": 65_000,
    },
    {
        "name": "🛠 СТО",
        "desc": "Профессиональная станция технического обслуживания с полным спектром услуг. Дорогостоящие ремонты, плановое ТО и детейлинг — живая очередь клиентов каждый день.",
        "price": 15_000_000,
        "income_per_hour": 110_000,
    },
    {
        "name": "🏪 Магазин 24/7",
        "desc": "Сеть круглосуточных магазинов в спальных районах. Высокая проходимость, широкий ассортимент и полная автоматизация кассового учёта делают этот бизнес золотой жилой.",
        "price": 30_000_000,
        "income_per_hour": 180_000,
    },
    {
        "name": "🎲 Игровой Клуб",
        "desc": "Элитный развлекательный клуб с премиальными игровыми зонами, баром и vip-кабинетами. Закрытое членство и высокий средний чек превращают каждый вечер в рекорд выручки.",
        "price": 60_000_000,
        "income_per_hour": 300_000,
    },
    {
        "name": "🏨 Отель",
        "desc": "Пятизвёздочный бутик-отель в историческом центре. Люксовые номера, ресторан высокой кухни и спа-комплекс привлекают состоятельных гостей со всего мира.",
        "price": 100_000_000,
        "income_per_hour": 450_000,
    },
    {
        "name": "✈️ Аэропорт",
        "desc": "Международный аэропорт с терминалами бизнес-авиации, duty-free зонами и грузовыми терминалами. Тысячи рейсов в месяц генерируют доходы, недоступные обычному бизнесу.",
        "price": 150_000_000,
        "income_per_hour": 600_000,
    },
]


# ──────────────────────────────────────────────
#  МАГАЗИН БИЗНЕСОВ (просмотр/покупка)
# ──────────────────────────────────────────────

def get_biz_shop_kb(idx: int, owned: list) -> InlineKeyboardMarkup:
    total = len(BUSINESSES)
    is_owned = idx in owned
    nav_row = []
    if idx > 0:
        nav_row.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"biz_shop_view:{idx - 1}"))
    if is_owned:
        nav_row.append(InlineKeyboardButton(text="🔒 Слот занят (1/1)", callback_data="biz_slot_full"))
    else:
        nav_row.append(InlineKeyboardButton(text="✅ Купить", callback_data=f"biz_shop_buy:{idx}"))
    if idx < total - 1:
        nav_row.append(InlineKeyboardButton(text="Далее ▶️", callback_data=f"biz_shop_view:{idx + 1}"))
    menu_row = [InlineKeyboardButton(text="🏠 Меню", callback_data="biz_shop_close")]
    return InlineKeyboardMarkup(inline_keyboard=[nav_row, menu_row])


def biz_shop_text(idx: int, owned: list) -> str:
    biz = BUSINESSES[idx]
    total = len(BUSINESSES)
    is_owned = idx in owned
    slot_line = "🔒 <b>Слот:</b> 1/1 — уже куплен" if is_owned else "🔓 <b>Слот:</b> 0/1 — доступен"
    return (
        f"🏢 <b>Бизнес {idx + 1}/{total}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{biz['name']}</b>\n\n"
        f"📝 {biz['desc']}\n\n"
        f"💰 <b>Стоимость:</b> {format_amount(biz['price'])}$\n"
        f"📈 <b>Прибыль в час:</b> {format_amount(biz['income_per_hour'])}$\n\n"
        f"{slot_line}"
    )


@router.message(F.text.lower().in_(["🏢 бизнес", "бизнес", "биз", "🏢 биз", "бизнесы", "/бизнес"]))
async def cmd_biz_smart(message: Message):
    from smart_assets import build_donate_biz_card
    user_id = message.from_user.id
    user = get_user(user_id)
    owned = user.get("businesses", [])
    if owned:
        await message.answer(my_biz_text(user, 0), reply_markup=my_biz_kb(user, 0), parse_mode="HTML")
        don_card = build_donate_biz_card(user_id)
        if don_card:
            text, kb = don_card
            await message.answer(text, reply_markup=kb, parse_mode="HTML")
    else:
        don_card = build_donate_biz_card(user_id)
        if don_card:
            text, kb = don_card
            await message.answer(text, reply_markup=kb, parse_mode="HTML")
        else:
            await message.answer(biz_shop_text(0, owned), reply_markup=get_biz_shop_kb(0, owned), parse_mode="HTML")


@router.message(F.text.lower().in_(["🏢 купить бизнес", "купить бизнес", "магазин бизнесов"]))
async def cmd_biz_shop_only(message: Message):
    user = get_user(message.from_user.id)
    owned = user.get("businesses", [])
    await message.answer(biz_shop_text(0, owned), reply_markup=get_biz_shop_kb(0, owned), parse_mode="HTML")


@router.callback_query(F.data.startswith("biz_shop_view:"))
async def cb_biz_shop_view(callback: CallbackQuery):
    idx = int(callback.data.split(":")[1])
    user = get_user(callback.from_user.id)
    owned = user.get("businesses", [])
    await callback.message.edit_text(biz_shop_text(idx, owned), reply_markup=get_biz_shop_kb(idx, owned), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "biz_slot_full")
async def cb_biz_slot_full(callback: CallbackQuery):
    await callback.answer("🔒 Слот занят! Продайте бизнес в разделе «Мои бизнесы».", show_alert=True)


@router.callback_query(F.data.startswith("biz_shop_buy:"))
async def cb_biz_shop_buy(callback: CallbackQuery):
    user_id = callback.from_user.id
    idx = int(callback.data.split(":")[1])
    biz = BUSINESSES[idx]

    user = get_user(user_id)
    balance = get_balance(user_id)

    owned = user.get("businesses", [])
    if idx in owned:
        await callback.answer("⚠️ Вы уже владеете этим бизнесом!", show_alert=True)
        return

    if balance < biz["price"]:
        await callback.answer(
            f"❌ Недостаточно средств!\nНужно: {format_amount(biz['price'])}$\nУ вас: {format_amount(balance)}$",
            show_alert=True
        )
        return

    update_balance(user_id, balance - biz["price"])
    owned.append(idx)
    user["businesses"] = owned

    if "biz_last_collect" not in user:
        user["biz_last_collect"] = {}
    user["biz_last_collect"][str(idx)] = int(time.time())

    save_user_data()

    await callback.answer(f"✅ {biz['name']} куплен!", show_alert=True)
    await callback.message.edit_text(
        f"✅ <b>Куплено: {biz['name']}</b>\n\n"
        f"📈 Прибыль: <b>{format_amount(biz['income_per_hour'])}$/ч</b>\n"
        f"💰 Баланс: <b>{format_amount(get_balance(user_id))}$</b>",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🏢 К бизнесам", callback_data=f"biz_shop_view:{idx}")],
            [InlineKeyboardButton(text="📦 Мои бизнесы", callback_data="mybiz_view:0")],
            [InlineKeyboardButton(text="🏠 Меню", callback_data="biz_shop_close")],
        ]),
        parse_mode="HTML"
    )


@router.callback_query(F.data == "biz_shop_close")
async def cb_biz_shop_close(callback: CallbackQuery):
    from keyboards import menu_kb
    from utils import safe_reply_kb
    await callback.message.delete()
    await callback.message.answer("Главное меню:", reply_markup=safe_reply_kb(callback.message, menu_kb))
    await callback.answer()


# ──────────────────────────────────────────────
#  МОИ БИЗНЕСЫ (просмотр/сбор/продажа)
# ──────────────────────────────────────────────

def _calc_income(user: dict, biz_idx: int) -> int:
    biz = BUSINESSES[biz_idx]
    last_collect = user.get("biz_last_collect", {}).get(str(biz_idx))
    if not last_collect:
        return 0
    elapsed_hours = (int(time.time()) - last_collect) / 3600
    return int(elapsed_hours * biz["income_per_hour"])


def my_biz_text(user: dict, pos: int) -> str:
    owned = user.get("businesses", [])
    total = len(owned)
    biz_idx = owned[pos]
    biz = BUSINESSES[biz_idx]
    income = _calc_income(user, biz_idx)
    sell_price = int(biz["price"] * SELL_RATIO)
    return (
        f"📦 <b>Мой бизнес {pos + 1}/{total}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{biz['name']}</b>\n\n"
        f"📝 {biz['desc']}\n\n"
        f"💰 <b>Стоимость:</b> {format_amount(biz['price'])}$\n"
        f"📈 <b>Прибыль в час:</b> {format_amount(biz['income_per_hour'])}$\n"
        f"💵 <b>Накоплено:</b> {format_amount(income)}$\n\n"
        f"🔴 Цена продажи: {format_amount(sell_price)}$"
    )


def my_biz_kb(user: dict, pos: int) -> InlineKeyboardMarkup:
    owned = user.get("businesses", [])
    total = len(owned)
    biz_idx = owned[pos]

    nav_row = []
    if pos > 0:
        nav_row.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"mybiz_view:{pos - 1}"))
    if pos < total - 1:
        nav_row.append(InlineKeyboardButton(text="Далее ▶️", callback_data=f"mybiz_view:{pos + 1}"))

    action_row = [
        InlineKeyboardButton(text="💵 Собрать", callback_data=f"mybiz_collect:{pos}"),
        InlineKeyboardButton(text="🔴 Продать", callback_data=f"mybiz_sell:{pos}"),
    ]
    menu_row = [InlineKeyboardButton(text="🏠 Меню", callback_data="biz_shop_close")]

    rows = []
    if nav_row:
        rows.append(nav_row)
    rows.append(action_row)
    rows.append(menu_row)
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.lower().in_(["мои бизнесы", "мой бизнес", "📦 мои бизнесы", "/мои_бизнесы"]))
async def cmd_my_biz(message: Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    owned = user.get("businesses", [])
    if not owned:
        await message.answer(
            "📦 У вас пока нет бизнесов.\n\nКупите бизнес в разделе <b>🏢 Бизнес</b>!",
            parse_mode="HTML"
        )
        return
    await message.answer(my_biz_text(user, 0), reply_markup=my_biz_kb(user, 0), parse_mode="HTML")


@router.callback_query(F.data.startswith("mybiz_view:"))
async def cb_mybiz_view(callback: CallbackQuery):
    user_id = callback.from_user.id
    pos = int(callback.data.split(":")[1])
    user = get_user(user_id)
    owned = user.get("businesses", [])
    if not owned:
        await callback.answer("У вас нет бизнесов.", show_alert=True)
        return
    pos = max(0, min(pos, len(owned) - 1))
    await callback.message.edit_text(my_biz_text(user, pos), reply_markup=my_biz_kb(user, pos), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("mybiz_collect:"))
async def cb_mybiz_collect(callback: CallbackQuery):
    user_id = callback.from_user.id
    pos = int(callback.data.split(":")[1])
    user = get_user(user_id)
    owned = user.get("businesses", [])
    if not owned or pos >= len(owned):
        await callback.answer("Бизнес не найден.", show_alert=True)
        return

    biz_idx = owned[pos]
    income = _calc_income(user, biz_idx)
    if income <= 0:
        await callback.answer("💤 Прибыль ещё не накопилась. Подождите немного!", show_alert=True)
        return

    update_balance(user_id, get_balance(user_id) + income)
    if "biz_last_collect" not in user:
        user["biz_last_collect"] = {}
    user["biz_last_collect"][str(biz_idx)] = int(time.time())
    save_user_data()

    await callback.answer(f"✅ Собрано: {format_amount(income)}$!", show_alert=True)
    user = get_user(user_id)
    await callback.message.edit_text(my_biz_text(user, pos), reply_markup=my_biz_kb(user, pos), parse_mode="HTML")


@router.callback_query(F.data.startswith("mybiz_sell:"))
async def cb_mybiz_sell(callback: CallbackQuery):
    user_id = callback.from_user.id
    pos = int(callback.data.split(":")[1])
    user = get_user(user_id)
    owned = user.get("businesses", [])
    if not owned or pos >= len(owned):
        await callback.answer("Бизнес не найден.", show_alert=True)
        return

    biz_idx = owned[pos]
    biz = BUSINESSES[biz_idx]

    income = _calc_income(user, biz_idx)
    sell_price = int(biz["price"] * SELL_RATIO)
    total_payout = sell_price + income

    update_balance(user_id, get_balance(user_id) + total_payout)
    owned.remove(biz_idx)
    user["businesses"] = owned
    if "biz_last_collect" in user:
        user["biz_last_collect"].pop(str(biz_idx), None)
    save_user_data()

    await callback.answer(f"🔴 Продано за {format_amount(sell_price)}$!", show_alert=True)

    user = get_user(user_id)
    new_owned = user.get("businesses", [])
    if not new_owned:
        await callback.message.edit_text(
            f"🔴 <b>{biz['name']}</b> продан!\n\n"
            f"💰 Получено: <b>{format_amount(sell_price)}$</b>"
            + (f"\n💵 + накопленная прибыль: <b>{format_amount(income)}$</b>" if income > 0 else "") +
            f"\n\n📦 Бизнесов больше нет.",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🏢 Купить бизнес", callback_data="biz_shop_view:0")],
                [InlineKeyboardButton(text="🏠 Меню", callback_data="biz_shop_close")],
            ]),
            parse_mode="HTML"
        )
    else:
        new_pos = min(pos, len(new_owned) - 1)
        await callback.message.edit_text(my_biz_text(user, new_pos), reply_markup=my_biz_kb(user, new_pos), parse_mode="HTML")
