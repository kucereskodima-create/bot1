from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils import get_user, get_balance, update_balance, save_user_data, format_amount

router = Router()

SELL_RATIO = 0.6

SHOP_CARS = {
    "lada_granta": {
        "name": "🚗 Lada Granta",
        "speed": 170,
        "price": 350_000,
        "desc": "Простой и надёжный отечественный автомобиль",
    },
    "toyota_camry": {
        "name": "🚗 Toyota Camry",
        "speed": 210,
        "price": 2_500_000,
        "desc": "Популярный японский седан бизнес-класса",
    },
    "bmw_3": {
        "name": "🚗 BMW 3 Series",
        "speed": 240,
        "price": 5_000_000,
        "desc": "Спортивный немецкий седан с отличной динамикой",
    },
    "mercedes_c": {
        "name": "🚗 Mercedes-Benz C-Class",
        "speed": 245,
        "price": 7_500_000,
        "desc": "Премиальный немецкий седан со стильным дизайном",
    },
    "audi_a6": {
        "name": "🚗 Audi A6",
        "speed": 250,
        "price": 9_000_000,
        "desc": "Элегантный немецкий седан высокого класса",
    },
    "porsche_cayenne": {
        "name": "🚙 Porsche Cayenne",
        "speed": 265,
        "price": 18_000_000,
        "desc": "Мощный спортивный внедорожник из Германии",
    },
    "bentley_continental": {
        "name": "🚗 Bentley Continental GT",
        "speed": 318,
        "price": 45_000_000,
        "desc": "Роскошный британский гран-туризмо",
    },
    "lamborghini_urus": {
        "name": "🚙 Lamborghini Urus",
        "speed": 305,
        "price": 70_000_000,
        "desc": "Самый быстрый SUV в мире от итальянского бренда",
    },
    "rolls_royce": {
        "name": "🚗 Rolls-Royce Ghost",
        "speed": 250,
        "price": 120_000_000,
        "desc": "Эталон роскоши и статуса на дороге",
    },
    "bugatti_chiron": {
        "name": "🚗 Bugatti Chiron",
        "speed": 420,
        "price": 500_000_000,
        "desc": "Гиперкар — самый быстрый серийный автомобиль в мире",
    },
}

CAR_KEYS = list(SHOP_CARS.keys())


def get_owned_car(user_id: int) -> str | None:
    user = get_user(user_id)
    return user.get("shop_car")


def car_shop_text(idx: int, owned_key: str | None) -> str:
    key = CAR_KEYS[idx]
    c = SHOP_CARS[key]
    total = len(CAR_KEYS)
    is_owned = owned_key == key
    owned_name = SHOP_CARS[owned_key]["name"] if owned_key and owned_key in SHOP_CARS else "Нет"
    if is_owned:
        slot_line = "🔒 <b>Слот:</b> 1/1 — уже куплен"
    elif owned_key:
        slot_line = "🔒 <b>Слот:</b> 1/1 — занят"
    else:
        slot_line = "🔓 <b>Слот:</b> 0/1 — свободен"
    return (
        f"🚗 <b>Автомобиль {idx + 1}/{total}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{c['name']}</b>\n"
        f"⚡ Скорость: <b>{c['speed']} км/ч</b>\n\n"
        f"📝 {c['desc']}\n\n"
        f"💰 <b>Стоимость:</b> {format_amount(c['price'])}$\n\n"
        f"{slot_line}\n"
        f"🚗 Ваше авто: <b>{owned_name}</b>"
    )


def get_car_shop_kb(idx: int, owned_key: str | None) -> InlineKeyboardMarkup:
    total = len(CAR_KEYS)
    key = CAR_KEYS[idx]
    is_owned = owned_key == key

    nav_row = []
    if idx > 0:
        nav_row.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"cshop_view:{idx - 1}"))
    if is_owned:
        nav_row.append(InlineKeyboardButton(text="🔒 Уже куплен", callback_data="cshop_slot_full"))
    else:
        nav_row.append(InlineKeyboardButton(text="✅ Купить", callback_data=f"cshop_buy_{key}"))
    if idx < total - 1:
        nav_row.append(InlineKeyboardButton(text="Далее ▶️", callback_data=f"cshop_view:{idx + 1}"))

    rows = [nav_row]
    if owned_key and owned_key in SHOP_CARS:
        sell_price = int(SHOP_CARS[owned_key]["price"] * SELL_RATIO)
        rows.append([InlineKeyboardButton(
            text=f"🔴 Продать {SHOP_CARS[owned_key]['name']} за {format_amount(sell_price)}$",
            callback_data=f"cshop_sell_{owned_key}"
        )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.lower().in_(["🚗 магазин авто", "магазин авто", "автосалон", "/автосалон", "купить авто", "/купить авто"]))
async def cmd_car_shop(message: Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    owned_key = user.get("shop_car")
    await message.answer(
        car_shop_text(0, owned_key),
        parse_mode="HTML",
        reply_markup=get_car_shop_kb(0, owned_key)
    )


@router.callback_query(F.data.startswith("cshop_view:"))
async def cb_cshop_view(callback: CallbackQuery):
    idx = int(callback.data.split(":")[1])
    user_id = callback.from_user.id
    user = get_user(user_id)
    owned_key = user.get("shop_car")
    await callback.message.edit_text(
        car_shop_text(idx, owned_key),
        parse_mode="HTML",
        reply_markup=get_car_shop_kb(idx, owned_key)
    )
    await callback.answer()


@router.callback_query(F.data == "cshop_slot_full")
async def cb_cshop_slot_full(callback: CallbackQuery):
    await callback.answer("🔒 Этот автомобиль уже ваш!", show_alert=True)


@router.callback_query(F.data.startswith("cshop_buy_"))
async def cb_cshop_buy(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    key = callback.data.replace("cshop_buy_", "")
    if key not in SHOP_CARS:
        await callback.answer("❌ Автомобиль не найден.", show_alert=True)
        return
    car = SHOP_CARS[key]
    owned = user.get("shop_car")
    idx = CAR_KEYS.index(key)
    if owned == key:
        await callback.answer("🔒 Слот занят (1/1) — этот автомобиль уже ваш!", show_alert=True)
        return
    balance = get_balance(user_id)
    if balance < car["price"]:
        await callback.answer(
            f"❌ Недостаточно средств!\nНужно: {format_amount(car['price'])}$\nУ вас: {format_amount(balance)}$",
            show_alert=True
        )
        return
    refund = 0
    old_text = ""
    if owned and owned in SHOP_CARS:
        refund = int(SHOP_CARS[owned]["price"] * SELL_RATIO)
        old_text = f"\n🔄 Старое авто продано за <b>{format_amount(refund)}$</b>"
    total_cost = car["price"] - refund
    update_balance(user_id, balance - total_cost)
    user["shop_car"] = key
    save_user_data()
    await callback.message.edit_text(
        f"✅ Вы купили <b>{car['name']}</b>!\n"
        f"💳 Стоимость: <b>{format_amount(car['price'])}$</b>{old_text}\n"
        f"⚡ Скорость: <b>{car['speed']} км/ч</b>\n\n"
        f"🚗 Ваше авто: <b>{car['name']}</b>",
        parse_mode="HTML",
        reply_markup=get_car_shop_kb(idx, key)
    )
    await callback.answer(f"✅ {car['name']} куплен!")


@router.callback_query(F.data.startswith("cshop_sell_"))
async def cb_cshop_sell(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    key = callback.data.replace("cshop_sell_", "")
    if key not in SHOP_CARS or user.get("shop_car") != key:
        await callback.answer("❌ Этот автомобиль вам не принадлежит.", show_alert=True)
        return
    sell_price = int(SHOP_CARS[key]["price"] * SELL_RATIO)
    update_balance(user_id, get_balance(user_id) + sell_price)
    user["shop_car"] = None
    save_user_data()
    await callback.message.edit_text(
        f"🔴 Вы продали <b>{SHOP_CARS[key]['name']}</b> за <b>{format_amount(sell_price)}$</b>.\n"
        "🚗 Ваше авто: <b>Нет</b>",
        parse_mode="HTML",
        reply_markup=get_car_shop_kb(0, None)
    )
    await callback.answer(f"Продано за {format_amount(sell_price)}$")
