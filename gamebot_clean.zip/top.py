"""
Система топа — рейтинг игроков по нескольким категориям.
"""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils import format_amount
import utils

router = Router()

MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}

# ─── Категории ────────────────────────────────────────────────────────────────
CATS = {
    "balance": {
        "label":  "💰 Баланс",
        "title":  "💰 ТОП 10 — БАЛАНС (КОШЕЛЁК)",
        "getter": lambda u: u.get("balance", 0),
        "fmt":    lambda v: f"{format_amount(int(v))}$",
    },
    "bank": {
        "label":  "🏦 Банк",
        "title":  "🏦 ТОП 10 — БАНКОВСКИЙ СЧЁТ",
        "getter": lambda u: u.get("user_bank", 0),
        "fmt":    lambda v: f"{format_amount(int(v))}$",
    },
    "total": {
        "label":  "💎 Всего",
        "title":  "💎 ТОП 10 — ОБЩЕЕ СОСТОЯНИЕ (баланс+банк)",
        "getter": lambda u: u.get("balance", 0) + u.get("user_bank", 0),
        "fmt":    lambda v: f"{format_amount(int(v))}$",
    },
    "level": {
        "label":  "📈 Уровень",
        "title":  "📈 ТОП 10 — УРОВЕНЬ",
        "getter": lambda u: u.get("level", 1),
        "fmt":    lambda v: f"Ур. {int(v)}",
    },
    "btc": {
        "label":  "₿ BTC",
        "title":  "₿ ТОП 10 — BTC КОШЕЛЁК",
        "getter": lambda u: u.get("farm", {}).get("btc_balance", 0.0),
        "fmt":    lambda v: f"{v:.4f} BTC".rstrip("0").rstrip(".") + " BTC",
    },
    "dc": {
        "label":  "💎 DC",
        "title":  "💎 ТОП 10 — ДОНАТ МОНЕТЫ (DC)",
        "getter": lambda u: u.get("donate_coins", 0),
        "fmt":    lambda v: f"{int(v)} DC",
    },
}

CAT_ORDER = ["balance", "bank", "total", "level", "btc", "dc"]


# ─── Вспомогательные ──────────────────────────────────────────────────────────

def _is_real_player(u: dict, val) -> bool:
    """Фильтр фейков: игрок считается реальным если у него есть хоть какой-то прогресс."""
    if val == 0:
        return False
    has_name = u.get("name", "Игрок") not in ("Игрок", "", None)
    has_progress = (
        u.get("balance", 0) > 0
        or u.get("user_bank", 0) > 0
        or u.get("level", 1) > 1
        or u.get("farm", {}).get("btc_balance", 0.0) > 0
        or u.get("donate_coins", 0) > 0
    )
    return has_name or has_progress


def _get_top(cat_key: str, limit: int = 10) -> list[tuple]:
    """Возвращает [(uid, name, value), ...] отсортированный по убыванию (без фейков)."""
    cat    = CATS[cat_key]
    getter = cat["getter"]
    rows   = []
    for uid, u in utils.user_data.items():
        val  = getter(u)
        if not _is_real_player(u, val):
            continue
        name = u.get("name", "Игрок")
        rows.append((uid, name, val))
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:limit]


def _caller_rank(caller_id: int, cat_key: str) -> int | None:
    cat    = CATS[cat_key]
    getter = cat["getter"]
    rows   = []
    for uid, u in utils.user_data.items():
        val = getter(u)
        if not _is_real_player(u, val):
            continue
        rows.append((uid, u))
    rows.sort(key=lambda kv: getter(kv[1]), reverse=True)
    for i, (uid, _) in enumerate(rows, 1):
        if str(uid) == str(caller_id):
            return i
    return None


def _build_text(cat_key: str, caller_id: int = None) -> str:
    cat   = CATS[cat_key]
    rows  = _get_top(cat_key)
    lines = [f"<b>{cat['title']}</b>", "━━━━━━━━━━━━━━━━━━━━", ""]

    for i, (uid, name, val) in enumerate(rows, 1):
        medal  = MEDALS.get(i, f"{i}.")
        vfmt   = cat["fmt"](val)
        lines.append(f"{medal} <b>{name}</b>  —  {vfmt}")

    if caller_id:
        rank = _caller_rank(caller_id, cat_key)
        lines += ["", "━━━━━━━━━━━━━━━━━━━━"]
        if rank and rank <= 10:
            lines.append(f"🎯 Ваше место: <b>#{rank}</b>  🏆")
        elif rank:
            lines.append(f"🎯 Ваше место: <b>#{rank}</b>")
        else:
            lines.append("🎯 Вы не в рейтинге")

    return "\n".join(lines)


def _build_kb(active: str) -> InlineKeyboardMarkup:
    rows = []
    row  = []
    for i, key in enumerate(CAT_ORDER):
        label = CATS[key]["label"]
        if key == active:
            label = f"› {label} ‹"
        row.append(InlineKeyboardButton(text=label, callback_data=f"top_cat:{key}"))
        if len(row) == 2 or i == len(CAT_ORDER) - 1:
            rows.append(row)
            row = []
    return InlineKeyboardMarkup(inline_keyboard=rows)


# ─── Хэндлеры ─────────────────────────────────────────────────────────────────

@router.message(F.text.lower().in_([
    "топ", "/топ", "рейтинг", "/рейтинг", "лидерборд", "top", "/top",
    "топ игроков", "🏆 топ", "📊 рейтинг"
]))
async def cmd_top(message: Message):
    cat_key = "balance"
    text    = _build_text(cat_key, message.from_user.id)
    kb      = _build_kb(cat_key)
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("top_cat:"))
async def cb_top_cat(callback: CallbackQuery):
    cat_key = callback.data.split(":")[1]
    if cat_key not in CATS:
        await callback.answer("Категория не найдена.")
        return
    text = _build_text(cat_key, callback.from_user.id)
    kb   = _build_kb(cat_key)
    try:
        await callback.message.edit_text(text, parse_mode="HTML", reply_markup=kb)
    except Exception:
        pass
    await callback.answer()
