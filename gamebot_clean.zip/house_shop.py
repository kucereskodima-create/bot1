from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils import get_user, get_balance, update_balance, save_user_data, format_amount

router = Router()

SELL_RATIO = 0.6

SHOP_HOUSES = {
    "abandoned": {
        "name": "🏚 Заброшенный дом",
        "price": 124_000,
        "work_boost": 0,
        "farm_boost": 0,
        "bonus_cd_pct": 3,
        "desc": "⏱ Бонус быстрее на 3%",
    },
    "tent": {
        "name": "🏕 Палатка",
        "price": 476_240,
        "work_boost": 2,
        "farm_boost": 0,
        "bonus_cd_pct": 0,
        "desc": "💼 Работа +2%",
    },
    "treehouse": {
        "name": "🏡 Домик на дереве",
        "price": 896_000,
        "work_boost": 0,
        "farm_boost": 2,
        "bonus_cd_pct": 0,
        "desc": "⛏ Ферма +2%",
    },
    "village": {
        "name": "🏠 Дом в посёлке",
        "price": 1_300_620,
        "work_boost": 0,
        "farm_boost": 0,
        "bonus_cd_pct": 5,
        "desc": "⏱ Бонус быстрее на 5%",
    },
    "city": {
        "name": "🏘 Дом в городе",
        "price": 2_540_000,
        "work_boost": 5,
        "farm_boost": 0,
        "bonus_cd_pct": 0,
        "desc": "💼 Работа +5%",
    },
    "moscow": {
        "name": "🏙 Дом в Москве",
        "price": 7_930_000,
        "work_boost": 0,
        "farm_boost": 5,
        "bonus_cd_pct": 0,
        "desc": "⛏ Ферма +5%",
    },
    "hotel": {
        "name": "🏤 Дом в отеле",
        "price": 11_250_500,
        "work_boost": 8,
        "farm_boost": 0,
        "bonus_cd_pct": 0,
        "desc": "💼 Работа +8%",
    },
    "maldives": {
        "name": "🏖 Дом на Мальдивах",
        "price": 15_000_000,
        "work_boost": 0,
        "farm_boost": 10,
        "bonus_cd_pct": 0,
        "desc": "⛏ Ферма +10%",
    },
    "mountains": {
        "name": "⛰ Дом в горах",
        "price": 35_000_000,
        "work_boost": 5,
        "farm_boost": 5,
        "bonus_cd_pct": 5,
        "desc": "💼 +5% работа · ⛏ +5% ферма · ⏱ -5% кд",
    },
}

HOUSE_KEYS = list(SHOP_HOUSES.keys())


def get_shop_house_boosts(user_id: int) -> dict:
    user = get_user(user_id)
    key = user.get("shop_house")
    if not key or key not in SHOP_HOUSES:
        return {"work_boost": 0, "farm_boost": 0, "bonus_cd_pct": 0}
    h = SHOP_HOUSES[key]
    return {
        "work_boost":   h.get("work_boost", 0),
        "farm_boost":   h.get("farm_boost", 0),
        "bonus_cd_pct": h.get("bonus_cd_pct", 0),
    }


def house_shop_text(idx: int, owned_key: str | None) -> str:
    key = HOUSE_KEYS[idx]
    h = SHOP_HOUSES[key]
    total = len(HOUSE_KEYS)
    is_owned = owned_key == key
    owned_name = SHOP_HOUSES[owned_key]["name"] if owned_key and owned_key in SHOP_HOUSES else "Нет"
    slot_line = "🔒 <b>Слот:</b> 1/1 — уже куплен" if is_owned else (
        "🔒 <b>Слот:</b> 1/1 — занят" if owned_key else "🔓 <b>Слот:</b> 0/1 — свободен"
    )
    return (
        f"🏠 <b>Дом {idx + 1}/{total}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"<b>{h['name']}</b>\n\n"
        f"🎁 <b>Буст:</b> {h['desc']}\n\n"
        f"💰 <b>Стоимость:</b> {format_amount(h['price'])}$\n\n"
        f"{slot_line}\n"
        f"🏡 Ваш дом: <b>{owned_name}</b>"
    )


def _menu_kb(owned_key: str | None) -> InlineKeyboardMarkup:
    return get_house_shop_kb(0, owned_key)


def get_house_shop_kb(idx: int, owned_key: str | None) -> InlineKeyboardMarkup:
    total = len(HOUSE_KEYS)
    key = HOUSE_KEYS[idx]
    is_owned = owned_key == key

    nav_row = []
    if idx > 0:
        nav_row.append(InlineKeyboardButton(text="◀️ Назад", callback_data=f"hshop_view:{idx - 1}"))
    if is_owned:
        nav_row.append(InlineKeyboardButton(text="🔒 Уже куплен", callback_data="hshop_slot_full"))
    else:
        nav_row.append(InlineKeyboardButton(text="✅ Купить", callback_data=f"hshop_buy_{key}"))
    if idx < total - 1:
        nav_row.append(InlineKeyboardButton(text="Далее ▶️", callback_data=f"hshop_view:{idx + 1}"))

    rows = [nav_row]
    if owned_key and owned_key in SHOP_HOUSES:
        sell_price = int(SHOP_HOUSES[owned_key]["price"] * SELL_RATIO)
        rows.append([InlineKeyboardButton(
            text=f"🔴 Продать {SHOP_HOUSES[owned_key]['name']} за {format_amount(sell_price)}$",
            callback_data=f"hshop_sell_{owned_key}"
        )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.lower().in_(["🏠 магазин домов", "магазин домов", "дома", "/дома"]))
async def cmd_house_shop(message: Message):
    user_id = message.from_user.id
    user = get_user(user_id)
    owned_key = user.get("shop_house")
    await message.answer(
        house_shop_text(0, owned_key),
        parse_mode="HTML",
        reply_markup=get_house_shop_kb(0, owned_key)
    )


@router.message(F.text.lower().in_(["дом", "🏡 дом", "мой дом", "моё жильё", "мое жилье", "🏡 мой дом"]))
async def cmd_house_smart(message: Message):
    from smart_assets import build_house_response, build_house_shop_response
    user_id = message.from_user.id
    result = build_house_response(user_id)
    if result:
        text, kb = result
        await message.answer(text, reply_markup=kb, parse_mode="HTML")
    else:
        text, kb = build_house_shop_response(user_id)
        await message.answer(text, reply_markup=kb, parse_mode="HTML")


@router.callback_query(F.data.startswith("hshop_view:"))
async def cb_hshop_view(callback: CallbackQuery):
    idx = int(callback.data.split(":")[1])
    user_id = callback.from_user.id
    user = get_user(user_id)
    owned_key = user.get("shop_house")
    await callback.message.edit_text(
        house_shop_text(idx, owned_key),
        parse_mode="HTML",
        reply_markup=get_house_shop_kb(idx, owned_key)
    )
    await callback.answer()


@router.callback_query(F.data == "hshop_slot_full")
async def cb_hshop_slot_full(callback: CallbackQuery):
    await callback.answer("🔒 Этот дом уже ваш!", show_alert=True)


@router.callback_query(F.data.startswith("hshop_buy_"))
async def cb_hshop_buy(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    key = callback.data.replace("hshop_buy_", "")
    if key not in SHOP_HOUSES:
        await callback.answer("❌ Дом не найден.", show_alert=True)
        return
    house = SHOP_HOUSES[key]
    owned = user.get("shop_house")
    idx = HOUSE_KEYS.index(key)
    if owned == key:
        await callback.answer("🔒 Слот занят (1/1) — этот дом уже ваш!", show_alert=True)
        return
    balance = get_balance(user_id)
    if balance < house["price"]:
        await callback.answer(
            f"❌ Недостаточно средств!\nНужно: {format_amount(house['price'])}$\nУ вас: {format_amount(balance)}$",
            show_alert=True
        )
        return
    refund = 0
    old_text = ""
    if owned and owned in SHOP_HOUSES:
        refund = int(SHOP_HOUSES[owned]["price"] * SELL_RATIO)
        old_text = f"\n🔄 Старый дом продан за <b>{format_amount(refund)}$</b>"
    total_cost = house["price"] - refund
    update_balance(user_id, balance - total_cost)
    user["shop_house"] = key
    save_user_data()
    await callback.message.edit_text(
        f"✅ Вы купили <b>{house['name']}</b>!\n"
        f"💳 Стоимость: <b>{format_amount(house['price'])}$</b>{old_text}\n"
        f"🎁 Буст: <b>{house['desc']}</b>\n\n"
        f"🏡 Текущий дом: <b>{house['name']}</b>",
        parse_mode="HTML",
        reply_markup=get_house_shop_kb(idx, key)
    )
    await callback.answer(f"✅ {house['name']} куплен!")


@router.callback_query(F.data == "myhouse_to_shop")
async def cb_myhouse_to_shop(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    owned_key = user.get("shop_house")
    await callback.message.edit_text(
        house_shop_text(0, owned_key),
        parse_mode="HTML",
        reply_markup=get_house_shop_kb(0, owned_key)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("hshop_sell_"))
async def cb_hshop_sell(callback: CallbackQuery):
    user_id = callback.from_user.id
    user = get_user(user_id)
    key = callback.data.replace("hshop_sell_", "")
    if key not in SHOP_HOUSES or user.get("shop_house") != key:
        await callback.answer("❌ Этот дом вам не принадлежит.", show_alert=True)
        return
    sell_price = int(SHOP_HOUSES[key]["price"] * SELL_RATIO)
    update_balance(user_id, get_balance(user_id) + sell_price)
    user["shop_house"] = None
    save_user_data()
    await callback.message.edit_text(
        f"🔴 Вы продали <b>{SHOP_HOUSES[key]['name']}</b> за <b>{format_amount(sell_price)}$</b>.\n"
        "🏡 Ваш дом: <b>Нет</b>",
        parse_mode="HTML",
        reply_markup=get_house_shop_kb(0, None)
    )
    await callback.answer(f"Продано за {format_amount(sell_price)}$")
