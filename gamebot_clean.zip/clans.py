import json
import os
import re
import time
import uuid
import datetime
from aiogram import Router, F
from aiogram.types import (
    Message, CallbackQuery,
    InlineKeyboardMarkup, InlineKeyboardButton,
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
import utils
from utils import parse_k

CLAN_CREATE_COST = 5_000_000

router = Router()

CLANS_FILE = os.path.join(os.path.dirname(__file__), "clans.json")
clans_data: dict = {}

ROLE_NAMES = {
    "owner":   "👑 Основатель",
    "deputy":  "⚔️ Заместитель",
    "watcher": "👁 Смотрящий",
    "member":  "👤 Участник",
}

MAX_CLAN_MEMBERS = 30
MAX_CLAN_NAME_LEN = 24


def load_clans():
    global clans_data
    if os.path.exists(CLANS_FILE):
        try:
            with open(CLANS_FILE, "r", encoding="utf-8") as f:
                clans_data = json.load(f)
        except Exception:
            clans_data = {}
    else:
        clans_data = {}


def save_clans():
    with open(CLANS_FILE, "w", encoding="utf-8") as f:
        json.dump(clans_data, f, ensure_ascii=False, indent=2)


load_clans()


def get_user_clan(user_id: int) -> dict | None:
    uid = str(user_id)
    for clan in clans_data.values():
        if uid in clan.get("members", {}):
            return clan
    return None


def _next_num_id() -> int:
    if not clans_data:
        return 1
    return max(c.get("num_id", 0) for c in clans_data.values()) + 1


def _fmt(n: float) -> str:
    if n >= 1_000_000_000:
        return f"{n / 1_000_000_000:.2f} млрд"
    if n >= 1_000_000:
        v = n / 1_000_000
        return f"{v:.1f} млн" if v < 100 else f"{int(v)} млн"
    if n >= 1_000:
        v = n / 1_000
        return f"{v:.1f} тыс" if v < 100 else f"{int(v)} тыс"
    return f"{int(n):,}".replace(",", ".")


CLAN_ICONS = [
    "🛡", "⚔️", "🔱", "🏴", "💀",
    "🐉", "🦅", "🌑", "⚡", "🔥",
    "❄️", "🌊", "🌪", "🏹", "🦁",
]


class ClanCreateState(StatesGroup):
    waiting_name = State()
    waiting_icon = State()


class TreasuryDepositState(StatesGroup):
    waiting_amount = State()


class ClanJoinState(StatesGroup):
    waiting_name = State()


def _icon_kb() -> InlineKeyboardMarkup:
    rows = []
    row = []
    for icon in CLAN_ICONS:
        row.append(InlineKeyboardButton(text=icon, callback_data=f"clan_icon:{icon}"))
        if len(row) == 5:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([InlineKeyboardButton(text="❌ Отмена", callback_data="clan_cancel")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _clan_main_kb(clan_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="👥 Участники", callback_data=f"clan_members:{clan_id}"),
            InlineKeyboardButton(text="🏦 Казна",      callback_data=f"clan_treasury:{clan_id}"),
        ],
        [
            InlineKeyboardButton(text="🏛 Центр",      callback_data=f"cx_main:{clan_id}"),
        ],
        [
            InlineKeyboardButton(text="ℹ️ Информация", callback_data=f"clan_info:{clan_id}"),
            InlineKeyboardButton(text="🚪 Выйти",      callback_data=f"clan_leave:{clan_id}"),
        ],
    ])


def _no_clan_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ Создать клан",  callback_data="clan_create")],
        [InlineKeyboardButton(text="🔍 Вступить в клан", callback_data="clan_join")],
        [InlineKeyboardButton(text="📋 Список кланов", callback_data="clan_list")],
    ])


def _clan_main_text(clan: dict, user_id: int) -> str:
    members = clan.get("members", {})
    role = members.get(str(user_id), "member")
    role_label = ROLE_NAMES.get(role, "👤 Участник")
    treasury = clan.get("treasury", 0)
    level = clan.get("level", 1)
    rating = clan.get("rating", 0)
    complex_lvl = clan.get("complex", {}).get("level", 1)
    return (
        f"╔══════════════════════╗\n"
        f"   {clan.get('icon', '🛡')}  <b>{clan['name'].upper()}</b>\n"
        f"╚══════════════════════╝\n\n"
        f"🎖 Ваша роль: <b>{role_label}</b>\n"
        f"👥 Участников: <b>{len(members)}</b> / {MAX_CLAN_MEMBERS}\n"
        f"📊 Уровень клана: <b>{level}</b>\n"
        f"⭐ Рейтинг: <b>{_fmt(rating)}</b>\n"
        f"🏦 Казна: <b>{_fmt(treasury)}$</b>\n"
        f"🏛 Центр добычи: <b>Ур. {complex_lvl}</b>\n\n"
        f"<i>Управляйте кланом через кнопки ниже</i>"
    )


async def _show_clan(message: Message, user_id: int):
    clan = get_user_clan(user_id)
    if clan:
        await message.answer(
            _clan_main_text(clan, user_id),
            parse_mode="HTML",
            reply_markup=_clan_main_kb(clan["id"])
        )
    else:
        await message.answer(
            "🛡 <b>КЛАНОВАЯ СИСТЕМА</b>\n\n"
            "Вы не состоите ни в одном клане.\n"
            "Создайте свой или вступите в существующий!",
            parse_mode="HTML",
            reply_markup=_no_clan_kb()
        )


@router.message(F.text.lower().in_([
    "клан", "/клан", "кланы", "/кланы", "clan", "/clan",
    "мой клан", "/мойклан",
]))
async def cmd_clan(message: Message):
    await _show_clan(message, message.from_user.id)


@router.message(F.text.lower().startswith("создать клан "))
async def cmd_create_clan_shortcut(message: Message, state: FSMContext):
    user_id = message.from_user.id
    if get_user_clan(user_id):
        await message.answer("❌ Вы уже состоите в клане!")
        return

    name = message.text.strip()[len("создать клан "):].strip()
    if len(name) < 2 or len(name) > MAX_CLAN_NAME_LEN:
        await message.answer(
            f"❌ Длина названия клана от 2 до {MAX_CLAN_NAME_LEN} символов.\n"
            f"Пример: <b>Создать клан МойКлан</b>",
            parse_mode="HTML"
        )
        return

    for c in clans_data.values():
        if c.get("name", "").lower() == name.lower():
            await message.answer("❌ Клан с таким именем уже существует. Выберите другое название.")
            return

    balance = utils.get_balance(user_id)
    if balance < CLAN_CREATE_COST:
        need = CLAN_CREATE_COST - balance
        await message.answer(
            f"❌ <b>Недостаточно средств!</b>\n\n"
            f"💰 Стоимость создания клана: <b>{_fmt(CLAN_CREATE_COST)}$</b>\n"
            f"💳 Ваш баланс: <b>{_fmt(balance)}$</b>\n"
            f"📉 Не хватает: <b>{_fmt(need)}$</b>",
            parse_mode="HTML"
        )
        return

    await state.update_data(clan_name=name, paid_create=True)
    await state.set_state(ClanCreateState.waiting_icon)
    await message.answer(
        f"✅ Название: <b>{name}</b>\n"
        f"💰 Стоимость: <b>{_fmt(CLAN_CREATE_COST)}$</b>\n\n"
        f"🎨 Выберите иконку клана:",
        parse_mode="HTML",
        reply_markup=_icon_kb()
    )


@router.message(F.text.lower().startswith("вступить "))
async def cmd_join_clan_by_id(message: Message, state: FSMContext):
    user_id = message.from_user.id
    if get_user_clan(user_id):
        await message.answer("❌ Вы уже состоите в клане!")
        return

    arg = message.text.strip().split(None, 1)[1].strip()
    if not arg.isdigit():
        await message.answer(
            "❌ Укажите числовой ID клана.\n"
            "Пример: <b>Вступить 3</b>\n\n"
            "Список кланов с ID можно посмотреть командой <b>Клан</b>.",
            parse_mode="HTML"
        )
        return

    num_id = int(arg)
    target = None
    for c in clans_data.values():
        if c.get("num_id") == num_id:
            target = c
            break

    if not target:
        await message.answer(f"❌ Клан с ID <b>#{num_id}</b> не найден.", parse_mode="HTML")
        return

    if len(target.get("members", {})) >= MAX_CLAN_MEMBERS:
        await message.answer("❌ Клан заполнен (достигнут лимит участников).")
        return

    if str(user_id) in target.get("members", {}):
        await message.answer("❌ Вы уже в этом клане.")
        return

    target["members"][str(user_id)] = "member"
    save_clans()
    await message.answer(
        f"✅ Вы вступили в клан {target.get('icon','')} <b>{target['name']}</b>!\n"
        f"🆔 ID клана: <code>#{num_id}</code>",
        parse_mode="HTML",
        reply_markup=_clan_main_kb(target["id"])
    )


@router.callback_query(F.data == "clan_create")
async def cb_clan_create(callback: CallbackQuery, state: FSMContext):
    if get_user_clan(callback.from_user.id):
        await callback.answer("❌ Вы уже состоите в клане!", show_alert=True)
        return
    await state.set_state(ClanCreateState.waiting_name)
    await callback.message.edit_text(
        "➕ <b>СОЗДАНИЕ КЛАНА</b>\n\n"
        "Введите название для вашего клана:\n"
        "<i>От 2 до 24 символов</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="clan_cancel")]
        ])
    )
    await callback.answer()


@router.callback_query(F.data == "clan_cancel")
async def cb_clan_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    clan = get_user_clan(callback.from_user.id)
    if clan:
        await callback.message.edit_text(
            _clan_main_text(clan, callback.from_user.id),
            parse_mode="HTML",
            reply_markup=_clan_main_kb(clan["id"])
        )
    else:
        await callback.message.edit_text(
            "🛡 <b>КЛАНОВАЯ СИСТЕМА</b>\n\nВы не состоите ни в одном клане.",
            parse_mode="HTML",
            reply_markup=_no_clan_kb()
        )
    await callback.answer()


@router.message(ClanCreateState.waiting_name)
async def msg_clan_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 2 or len(name) > MAX_CLAN_NAME_LEN:
        await message.answer(
            f"❌ Длина названия от 2 до {MAX_CLAN_NAME_LEN} символов. Попробуйте ещё раз."
        )
        return
    for c in clans_data.values():
        if c.get("name", "").lower() == name.lower():
            await message.answer("❌ Клан с таким именем уже существует. Введите другое.")
            return
    await state.update_data(clan_name=name)
    await state.set_state(ClanCreateState.waiting_icon)
    await message.answer(
        f"✅ Название: <b>{name}</b>\n\n🎨 Выберите иконку клана:",
        parse_mode="HTML",
        reply_markup=_icon_kb()
    )


@router.callback_query(ClanCreateState.waiting_icon, F.data.startswith("clan_icon:"))
async def cb_clan_icon(callback: CallbackQuery, state: FSMContext):
    icon = callback.data.split(":", 1)[1]
    data = await state.get_data()
    name = data.get("clan_name", "Клан")
    paid_create = data.get("paid_create", False)
    user_id = callback.from_user.id
    await state.clear()

    if get_user_clan(user_id):
        await callback.answer("❌ Вы уже состоите в клане!", show_alert=True)
        return

    if paid_create:
        balance = utils.get_balance(user_id)
        if balance < CLAN_CREATE_COST:
            await callback.answer("❌ Недостаточно средств для создания клана!", show_alert=True)
            return
        utils.update_balance(user_id, balance - CLAN_CREATE_COST)

    clan_id = str(uuid.uuid4())[:8]
    now = int(time.time())
    clan = {
        "id": clan_id,
        "num_id": _next_num_id(),
        "name": name,
        "icon": icon,
        "owner_id": user_id,
        "members": {str(user_id): "owner"},
        "created_at": now,
        "treasury": 0,
        "level": 1,
        "rating": 0,
        "complex": {
            "level": 1,
            "resources": {
                "diamonds": 0.0, "gold": 0.0, "titan": 0.0,
                "energycores": 0.0, "uranium": 0.0,
            },
            "last_update": now,
            "upgrade_fund": 0,
            "investors": {},
        }
    }
    clans_data[clan_id] = clan
    save_clans()

    cost_line = f"💰 Списано: <b>{_fmt(CLAN_CREATE_COST)}$</b>\n\n" if paid_create else "\n"
    await callback.message.edit_text(
        f"🎉 <b>Клан успешно создан!</b>\n\n"
        f"{icon} <b>{name}</b>\n"
        f"👑 Основатель: {callback.from_user.full_name}\n"
        f"{cost_line}"
        f"Начните развивать клан прямо сейчас!",
        parse_mode="HTML",
        reply_markup=_clan_main_kb(clan_id)
    )
    await callback.answer("✅ Клан создан!")


@router.callback_query(F.data == "clan_join")
async def cb_clan_join(callback: CallbackQuery, state: FSMContext):
    if get_user_clan(callback.from_user.id):
        await callback.answer("❌ Вы уже в клане!", show_alert=True)
        return
    await state.set_state(ClanJoinState.waiting_name)
    await callback.message.edit_text(
        "🔍 <b>ВСТУПЛЕНИЕ В КЛАН</b>\n\nВведите точное название клана:",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отмена", callback_data="clan_cancel")]
        ])
    )
    await callback.answer()


@router.message(ClanJoinState.waiting_name)
async def msg_clan_join(message: Message, state: FSMContext):
    user_id = message.from_user.id
    text = message.text.strip()
    target = None
    for c in clans_data.values():
        if c.get("name", "").lower() == text.lower():
            target = c
            break
    if not target:
        await message.answer("❌ Клан не найден. Проверьте название и попробуйте ещё раз.")
        return
    if len(target.get("members", {})) >= MAX_CLAN_MEMBERS:
        await message.answer("❌ Клан заполнен.")
        await state.clear()
        return
    if str(user_id) in target.get("members", {}):
        await message.answer("❌ Вы уже в этом клане.")
        await state.clear()
        return
    await state.clear()
    target["members"][str(user_id)] = "member"
    save_clans()
    await message.answer(
        f"✅ Вы вступили в клан <b>{target.get('icon','')} {target['name']}</b>!",
        parse_mode="HTML",
        reply_markup=_clan_main_kb(target["id"])
    )


@router.callback_query(F.data == "clan_list")
async def cb_clan_list(callback: CallbackQuery):
    if not clans_data:
        await callback.answer("📋 Кланов пока нет.", show_alert=True)
        return
    sorted_clans = sorted(
        clans_data.values(),
        key=lambda c: c.get("rating", 0),
        reverse=True
    )[:15]
    lines = ["📋 <b>СПИСОК КЛАНОВ</b>\n"]
    medals = ["🥇", "🥈", "🥉"] + ["🏅"] * 12
    for i, c in enumerate(sorted_clans):
        mc = len(c.get("members", {}))
        num = c.get("num_id", "—")
        lines.append(
            f"{medals[i]} <code>#{num}</code> {c.get('icon','🛡')} <b>{c['name']}</b> "
            f"— {mc} уч. | ⭐{_fmt(c.get('rating', 0))}"
        )
    lines.append("\n<i>Вступить по ID: напиши <b>Вступить (номер)</b></i>")
    await callback.message.edit_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔍 Вступить по названию", callback_data="clan_join")],
            [InlineKeyboardButton(text="⬅️ Назад",    callback_data="clan_no_clan_back")],
        ])
    )
    await callback.answer()


@router.callback_query(F.data == "clan_no_clan_back")
async def cb_no_clan_back(callback: CallbackQuery):
    await callback.message.edit_text(
        "🛡 <b>КЛАНОВАЯ СИСТЕМА</b>\n\nВы не состоите ни в одном клане.",
        parse_mode="HTML",
        reply_markup=_no_clan_kb()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_back:"))
async def cb_clan_back(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    await callback.message.edit_text(
        _clan_main_text(clan, user_id),
        parse_mode="HTML",
        reply_markup=_clan_main_kb(clan_id)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_members:"))
async def cb_clan_members(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    members = clan.get("members", {})
    role_order = {"owner": 0, "deputy": 1, "watcher": 2, "member": 3}
    sorted_members = sorted(members.items(), key=lambda x: role_order.get(x[1], 9))
    lines = [
        f"👥 <b>УЧАСТНИКИ</b>",
        f"━━━━━━━━━━━━━━━━━━━━",
        f"{clan.get('icon','')} <b>{clan['name']}</b>\n",
    ]
    for uid, role in sorted_members:
        u = utils.user_data.get(uid, {})
        name = u.get("name", f"ID {uid}")
        role_label = ROLE_NAMES.get(role, "👤 Участник")
        lines.append(f"{role_label}: <b>{name}</b>")
    lines.append(f"\n<i>Всего: {len(members)} / {MAX_CLAN_MEMBERS}</i>")
    await callback.message.edit_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"clan_back:{clan_id}")]
        ])
    )
    await callback.answer()


def _treasury_kb(clan_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💸 Вложить в казну", callback_data=f"clan_treasury_deposit:{clan_id}")],
        [InlineKeyboardButton(text="⬅️ Назад",           callback_data=f"clan_back:{clan_id}")],
    ])


@router.callback_query(F.data.startswith("clan_treasury:"))
async def cb_clan_treasury(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    treasury  = clan.get("treasury", 0)
    my_bal    = utils.get_balance(user_id)
    top_lines = []
    donors    = clan.get("donors", {})
    if donors:
        sorted_d = sorted(donors.items(), key=lambda x: x[1], reverse=True)[:5]
        top_lines.append("\n🏆 <b>Топ вкладчиков:</b>")
        for i, (uid_str, amt) in enumerate(sorted_d, 1):
            u = utils.get_user(int(uid_str))
            name = u.get("name", "—") if u else f"ID {uid_str}"
            top_lines.append(f"  {i}. {name} — <b>{_fmt(amt)}$</b>")
    await callback.message.edit_text(
        f"🏦 <b>КАЗНА КЛАНА</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"{clan.get('icon', '🛡')} <b>{clan['name']}</b>\n\n"
        f"💰 Баланс казны: <b>{_fmt(treasury)}$</b>\n"
        f"💼 Ваш баланс: <b>{_fmt(my_bal)}$</b>\n"
        + "\n".join(top_lines) +
        f"\n\n<i>Ресурсы Центра добычи и личные взносы пополняют казну.</i>\n"
        f"<i>Команда: <code>вб 5кк</code></i>",
        parse_mode="HTML",
        reply_markup=_treasury_kb(clan_id)
    )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_treasury_deposit:"))
async def cb_clan_treasury_deposit(callback: CallbackQuery, state: FSMContext):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    balance = utils.get_balance(user_id)
    await state.set_state(TreasuryDepositState.waiting_amount)
    await state.update_data(clan_id=clan_id)
    await callback.message.edit_text(
        f"💸 <b>ВЛОЖИТЬ В КАЗНУ</b>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n\n"
        f"{clan.get('icon','🛡')} <b>{clan['name']}</b>\n"
        f"🏦 Казна: <b>{_fmt(clan.get('treasury', 0))}$</b>\n"
        f"💼 Ваш баланс: <b>{_fmt(balance)}$</b>\n\n"
        f"Введите сумму для вклада:\n"
        f"<i>(примеры: <code>5кк</code>, <code>500к</code>, <code>1000000</code>)</i>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="❌ Отмена", callback_data=f"clan_treasury:{clan_id}")
        ]])
    )
    await callback.answer()


@router.message(TreasuryDepositState.waiting_amount)
async def msg_treasury_deposit(message: Message, state: FSMContext):
    user_id = message.from_user.id
    data    = await state.get_data()
    clan_id = data.get("clan_id")

    if not clan_id:
        await state.clear()
        await message.answer("❌ Сессия устарела. Зайди в меню клана заново.")
        return

    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await state.clear()
        await message.answer("❌ Клан не найден.")
        return

    amount = parse_k(message.text.strip())
    if not amount or amount <= 0:
        await message.answer(
            "❌ Неверная сумма. Примеры: <code>5кк</code>, <code>500к</code>, <code>1000000</code>",
            parse_mode="HTML"
        )
        return

    balance = utils.get_balance(user_id)
    if amount > balance:
        await message.answer(
            f"❌ Недостаточно средств.\n💼 Ваш баланс: <b>{_fmt(balance)}$</b>",
            parse_mode="HTML"
        )
        return

    await state.clear()

    utils.update_balance(user_id, balance - amount)
    clan["treasury"] = clan.get("treasury", 0) + amount
    if "donors" not in clan:
        clan["donors"] = {}
    uid_str = str(user_id)
    clan["donors"][uid_str] = clan["donors"].get(uid_str, 0) + amount
    save_clans()
    utils.save_user_data()

    user_name = utils.get_user(user_id).get("name", message.from_user.full_name)
    await message.answer(
        f"✅ <b>Взнос принят!</b>\n\n"
        f"{clan.get('icon','🛡')} <b>{clan['name']}</b>\n"
        f"💸 Вложено: <b>{_fmt(amount)}$</b>\n"
        f"🏦 Казна клана: <b>{_fmt(clan['treasury'])}$</b>\n"
        f"💼 Ваш баланс: <b>{_fmt(utils.get_balance(user_id))}$</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🏦 Казна", callback_data=f"clan_treasury:{clan_id}"),
            InlineKeyboardButton(text="🏠 Клан",  callback_data=f"clan_back:{clan_id}"),
        ]])
    )

    owner_id = clan.get("owner_id")
    if owner_id and owner_id != user_id:
        try:
            from config import bot
            await bot.send_message(
                owner_id,
                f"🏦 <b>{user_name}</b> вложил <b>{_fmt(amount)}$</b> в казну клана!\n"
                f"💰 Итого в казне: <b>{_fmt(clan['treasury'])}$</b>",
                parse_mode="HTML"
            )
        except Exception:
            pass


@router.callback_query(F.data.startswith("clan_info:"))
async def cb_clan_info(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    created = clan.get("created_at", 0)
    dt = datetime.datetime.fromtimestamp(created).strftime("%d.%m.%Y")
    owner_uid = str(clan.get("owner_id", ""))
    owner_name = utils.user_data.get(owner_uid, {}).get("name", "Неизвестно")
    complex_lvl = clan.get("complex", {}).get("level", 1)
    lines = [
        "ℹ️ <b>ИНФОРМАЦИЯ О КЛАНЕ</b>",
        "━━━━━━━━━━━━━━━━━━━━",
        "",
        f"{clan.get('icon', '🛡')} <b>{clan['name']}</b>",
        f"🆔 ID: <code>{clan.get('num_id', '—')}</code>",
        f"👑 Основатель: <b>{owner_name}</b>",
        f"📅 Создан: <b>{dt}</b>",
        f"👥 Участников: <b>{len(clan.get('members', {}))}</b> / {MAX_CLAN_MEMBERS}",
        f"📊 Уровень: <b>{clan.get('level', 1)}</b>",
        f"⭐ Рейтинг: <b>{_fmt(clan.get('rating', 0))}</b>",
        f"🏦 Казна: <b>{_fmt(clan.get('treasury', 0))}$</b>",
        f"🏛 Центр добычи: <b>Ур. {complex_lvl}</b>",
    ]
    await callback.message.edit_text(
        "\n".join(lines),
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⬅️ Назад", callback_data=f"clan_back:{clan_id}")]
        ])
    )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_leave:"))
async def cb_clan_leave(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    role = clan["members"].get(str(user_id), "member")
    is_owner = (role == "owner")

    if is_owner and len(clan["members"]) > 1:
        await callback.message.edit_text(
            f"⚠️ Вы основатель клана <b>{clan['name']}</b>.\n\n"
            f"Нельзя покинуть клан, пока есть участники.\n"
            f"Исключите всех или распустите клан.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🗑 Распустить клан", callback_data=f"clan_disband:{clan_id}")],
                [InlineKeyboardButton(text="⬅️ Назад",           callback_data=f"clan_back:{clan_id}")],
            ])
        )
    elif is_owner:
        await callback.message.edit_text(
            f"⚠️ Распустить клан <b>{clan['name']}</b>?\n\nЭто действие необратимо.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ Да, распустить",  callback_data=f"clan_disband:{clan_id}")],
                [InlineKeyboardButton(text="❌ Отмена",           callback_data=f"clan_back:{clan_id}")],
            ])
        )
    else:
        await callback.message.edit_text(
            f"⚠️ Покинуть клан <b>{clan['name']}</b>?",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="✅ Да, выйти", callback_data=f"clan_leave_ok:{clan_id}")],
                [InlineKeyboardButton(text="❌ Отмена",    callback_data=f"clan_back:{clan_id}")],
            ])
        )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_leave_ok:"))
async def cb_clan_leave_ok(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan or str(user_id) not in clan.get("members", {}):
        await callback.answer("❌", show_alert=True)
        return
    name = clan.get("name", "Клан")
    icon = clan.get("icon", "🛡")
    del clan["members"][str(user_id)]
    save_clans()
    await callback.message.edit_text(
        f"✅ Вы покинули клан <b>{icon} {name}</b>.",
        parse_mode="HTML",
        reply_markup=_no_clan_kb()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("clan_disband:"))
async def cb_clan_disband(callback: CallbackQuery):
    user_id = callback.from_user.id
    clan_id = callback.data.split(":", 1)[1]
    clan = clans_data.get(clan_id)
    if not clan:
        await callback.answer("❌", show_alert=True)
        return
    if clan.get("owner_id") != user_id:
        await callback.answer("❌ Только основатель может распустить клан.", show_alert=True)
        return
    name = clan.get("name", "Клан")
    del clans_data[clan_id]
    save_clans()
    await callback.message.edit_text(
        f"🗑 Клан <b>{name}</b> распущен.",
        parse_mode="HTML",
        reply_markup=_no_clan_kb()
    )
    await callback.answer("✅")


# ══════════════════════════════════════════════════════════════════
#  Быстрая команда: «вб 5кк» — вложить в казну клана
# ══════════════════════════════════════════════════════════════════

@router.message(F.text.lower().startswith("вб "))
async def cmd_vb_treasury(message: Message):
    user_id = message.from_user.id
    clan = get_user_clan(user_id)
    if not clan:
        await message.answer("❌ Вы не состоите в клане.")
        return

    raw    = message.text.strip()[3:].strip()
    amount = parse_k(raw)
    if not amount or amount <= 0:
        await message.answer(
            "❌ Укажи сумму. Примеры:\n"
            "<code>вб 5кк</code>\n"
            "<code>вб 500к</code>\n"
            "<code>вб 1000000</code>",
            parse_mode="HTML"
        )
        return

    balance = utils.get_balance(user_id)
    if amount > balance:
        await message.answer(
            f"❌ Недостаточно средств.\n"
            f"💼 Ваш баланс: <b>{_fmt(balance)}$</b>",
            parse_mode="HTML"
        )
        return

    clan_id = clan.get("id")
    utils.update_balance(user_id, balance - amount)
    clan["treasury"] = clan.get("treasury", 0) + amount
    if "donors" not in clan:
        clan["donors"] = {}
    uid_str = str(user_id)
    clan["donors"][uid_str] = clan["donors"].get(uid_str, 0) + amount
    save_clans()
    utils.save_user_data()

    user_name = utils.get_user(user_id).get("name", message.from_user.full_name)
    await message.answer(
        f"✅ <b>Взнос в казну клана принят!</b>\n\n"
        f"{clan.get('icon','🛡')} <b>{clan['name']}</b>\n"
        f"💸 Вложено: <b>{_fmt(amount)}$</b>\n"
        f"🏦 Казна клана: <b>{_fmt(clan['treasury'])}$</b>\n"
        f"💼 Ваш баланс: <b>{_fmt(utils.get_balance(user_id))}$</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="🏦 Казна", callback_data=f"clan_treasury:{clan_id}"),
            InlineKeyboardButton(text="🏠 Клан",  callback_data=f"clan_back:{clan_id}"),
        ]])
    )

    owner_id = clan.get("owner_id")
    if owner_id and owner_id != user_id:
        try:
            from config import bot
            await bot.send_message(
                owner_id,
                f"🏦 <b>{user_name}</b> вложил <b>{_fmt(amount)}$</b> в казну!\n"
                f"💰 Итого в казне: <b>{_fmt(clan['treasury'])}$</b>",
                parse_mode="HTML"
            )
        except Exception:
            pass